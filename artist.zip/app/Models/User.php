<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class User extends Model
{
    use HasFactory;

    protected $fillable = ['common_fields_id'];

    public function commonFields()
    {
        return $this->belongsTo(CommonFields::class);
    }
}
