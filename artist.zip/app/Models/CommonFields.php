<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Database\Eloquent\Model;

class CommonFields extends Model implements AuthenticatableContract
{
    use Authenticatable, HasFactory, Notifiable;

    protected $fillable = [
        'firstname', 'lastname', 'email', 'phonenumber', 'password', 'bio',
    ];

    public function user()
    {
        return $this->hasOne(User::class);
    }

    public function artist()
    {
        return $this->hasOne(Artist::class);
    }
}
