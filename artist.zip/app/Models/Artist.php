<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Artist extends Model
{
    use HasFactory;

    protected $fillable = ['common_fields_id', 'username', 'city', 'country', 'portfolio', 'socialmedia', 'bio', 'artistic_aspirations', 'artist_quote', 'independent_artist', 'gallery_representative', 'sell_original_artworks','sell_digital_creations'];

    protected $casts = [
        'independent_artist' => 'boolean',
        'gallery_representative' => 'boolean',
        'sell_original_artworks' => 'boolean',
        'sell_digital_creations' => 'boolean',
    ];

    public function commonFields()
    {
        return $this->belongsTo(CommonFields::class);
    }
}
