<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('artists', function (Blueprint $table) {
            $table->id();
            $table->foreignId('common_fields_id')->constrained('common_fields');
            $table->string('username');
            $table->string('city');
            $table->string('country');
            $table->text('portfolio')->nullable();
            $table->string('socialmedia')->nullable();
            $table->text('bio');
            $table->text('artistic_aspirations')->nullable();
            $table->text('artist_quote')->nullable();
            $table->text('profile_picture')->nullable();
            $table->boolean('independent_artist'); 
            $table->boolean('gallery_representative');
            $table->boolean('sell_original_artworks');
            $table->boolean('sell_digital_creations');
            $table->boolean('agree_terms')->default(true);
            $table->string('art_samples')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('artists');
    }
};
