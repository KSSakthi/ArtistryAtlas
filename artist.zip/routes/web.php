<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AboutController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\Auth\UserController;
use App\Http\Controllers\Auth\ArtistController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
// Route::get('/register', [RegisterController::class, 'showRegistrationForm'])->name('register');
// Route::post('/register', [RegisterController::class, 'customCreate'])->name('register.create');


Route::get('/', [HomeController::class, 'index'])->name('home');
Route::get('/about', [AboutController::class, 'index'])->name('about');

Route::get('/home', function () {
    return view('home');
});

Route::get('/contact', function () {
    return view('contact');
});
Route::get('/contact', [ContactController::class, 'index'])->name('contact');

// Route::get('/register', [\App\Http\Controllers\Auth\UserController::class, 'showRegistrationForm'])->name('register');
// Route::post('/register', [\App\Http\Controllers\Auth\UserController::class, 'register'])->name('register.store');

// Route::get('/artist/register', [\App\Http\Controllers\Auth\ArtistController::class, 'showRegistrationForm'])->name('artist.register');
// Route::post('/artist/register', [\App\Http\Controllers\Auth\ArtistController::class, 'register'])->name('artist.register.store');


use App\Http\Controllers\Auth\RegistrationController;

// User Registration
Route::get('/register', [RegistrationController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [RegistrationController::class, 'register'])->name('register.store');

// Artist Registration
Route::get('/artist/register', [RegistrationController::class, 'showArtistRegistrationForm'])->name('artist.register');
Route::post('/artist/register', [RegistrationController::class, 'registerArtist'])->name('artist.register.store');


Route::get('/artist/login', function () {
    return view('auth.login1');
})->name('artist.login');

// Handle creator login attempts


Route::get('/user/login', function () {
    return view('auth.login');
})->name('user.login');