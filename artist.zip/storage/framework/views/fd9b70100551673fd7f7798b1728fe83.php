
!
<?php $__env->startComponent('mail::message'); ?>
Welcome to ArtisanAtlas
      
Name: <?php echo e($mailData['name']); ?><br/>
Email: <?php echo e($mailData['email']); ?>

      
Thanks,<br/>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?><?php /**PATH E:\SAKTHI\welcome\resources\views/emails/welcome.blade.php ENDPATH**/ ?>